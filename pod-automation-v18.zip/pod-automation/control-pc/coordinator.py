"""
coordinator.py

The control PC's multiplayer coordinator: the single source of truth
for which pods exist, who's inviting whom, what the inviter has
configured so far, and which of the 4 acServer instances is assigned
to an active group. Pods' browsers talk to this service directly
(CORS-enabled below) rather than through their own pod's Flask app,
except for the one step that has to happen locally on each pod --
actually writing race.ini and launching acs.exe once a session starts
(that's phase1/app.py's /api/mp/join, on each pod).

State model
-----------
Pod: {pod_id, ip, status, last_seen, group_id}
    status: "idle" | "invited" | "in_group"

Group: {
    group_id, inviter_pod_id, member_pod_ids (inviter first),
    invite_status: {pod_id: "pending"|"accepted"|"declined"},
    state: "pending" | "active" | "ended",
    config: {pack_id, car_id, track_id, track_layout, session_type,
              duration_minutes, customer_names: {pod_id: name}},
    acserver_instance: int | None,
    created_at, ended_reason,
}

Scope decision, flagged rather than silently assumed: the INVITER
picks pack/car/track/session/duration for the whole group (same car
for everyone), not each pod picking its own car independently. Keeps
the acServer entry_list.ini assignment simple (see acserver_manager.py)
and the invite flow easy to follow. Straightforward to extend to
per-pod car choice later once the core join mechanism is proven on
real hardware -- that's the bigger unknown here, not this.

Live updates: each pod holds one persistent SSE connection to
GET /api/pods/<pod_id>/events, opened as soon as its kiosk app loads
(even before joining any group -- that's how it finds out it's been
invited in the first place). Whatever group that pod is part of, all
of that group's events (config changes, accept/decline, session
started/ended) get pushed down that same connection.

Known gap, not built here: nothing currently calls
end_group(..., reason="time_expired") automatically. That needs the
booking-clock hook described in the architecture brief (Section 4) --
still not built, same gap noted for phase1's single-player race
sessions. The capability is here and ready; nothing wires it up yet.

Run with:
    pip install -r requirements.txt
    python coordinator.py
Listens on 0.0.0.0:6000 by default.
"""

import json
import os
import queue
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from flask import Flask, jsonify, request, Response

import acserver_manager

APP_DIR = os.path.dirname(os.path.abspath(__file__))
POOL_CONFIG_PATH = os.path.join(APP_DIR, "acserver_pool.json")

INVITE_TIMEOUT_SECONDS = 60
SWEEP_INTERVAL_SECONDS = 5

app = Flask(__name__)
_lock = threading.Lock()

pods: Dict[str, dict] = {}
groups: Dict[str, dict] = {}
_subscribers: Dict[str, List["queue.Queue"]] = {}
_running_instances: Dict[int, object] = {}  # instance id -> subprocess.Popen


def _load_pool_config() -> dict:
    if not os.path.isfile(POOL_CONFIG_PATH):
        raise FileNotFoundError(
            f"{POOL_CONFIG_PATH} not found. Copy acserver_pool.example.json "
            f"to acserver_pool.json and fill in your acServer.exe path and "
            f"the 4 instances' ports/config folders."
        )
    with open(POOL_CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def _publish(pod_id: str, event: str, data: dict) -> None:
    payload = json.dumps(data)
    for q in _subscribers.get(pod_id, []):
        q.put((event, payload))


def _publish_to_group(group: dict, event: str, data: dict) -> None:
    for pod_id in group["member_pod_ids"]:
        _publish(pod_id, event, data)


def _free_instance_id(pool_cfg: dict) -> Optional[int]:
    used = {g["acserver_instance"] for g in groups.values() if g["state"] == "active" and g["acserver_instance"]}
    for inst in pool_cfg["instances"]:
        if inst["id"] not in used:
            return inst["id"]
    return None


def _end_group(group: dict, reason: str) -> None:
    """Caller must hold _lock."""
    if group["state"] == "ended":
        return
    group["state"] = "ended"
    group["ended_reason"] = reason

    if group["acserver_instance"] is not None:
        proc = _running_instances.pop(group["acserver_instance"], None)
        acserver_manager.stop_instance(proc)
        group["acserver_instance"] = None

    for pod_id in group["member_pod_ids"]:
        pod = pods.get(pod_id)
        if pod:
            pod["status"] = "idle"
            pod["group_id"] = None

    _publish_to_group(group, "session_ended", {"group_id": group["group_id"], "reason": reason})


def _sweep_expired_invites() -> None:
    while True:
        time.sleep(SWEEP_INTERVAL_SECONDS)
        with _lock:
            now = time.time()
            for group in list(groups.values()):
                if group["state"] != "pending":
                    continue
                if now - group["created_at"] < INVITE_TIMEOUT_SECONDS:
                    continue
                still_pending = [
                    pod_id for pod_id, status in group["invite_status"].items()
                    if status == "pending"
                ]
                if still_pending:
                    for pod_id in still_pending:
                        group["invite_status"][pod_id] = "timed_out"
                    _end_group(group, reason="timed_out")


threading.Thread(target=_sweep_expired_invites, daemon=True).start()


@app.after_request
def _add_cors_headers(resp):
    # Pods' browsers (served from each pod's own Flask app, a different
    # origin than this coordinator) call this API directly.
    # Closed LAN kiosk system -- wide-open CORS is fine here.
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return resp


@app.route("/api/pods/<pod_id>/register", methods=["POST", "OPTIONS"])
def api_register_pod(pod_id):
    if request.method == "OPTIONS":
        return ""
    with _lock:
        pod = pods.get(pod_id)
        if pod is None:
            pod = {"pod_id": pod_id, "ip": "", "status": "idle", "group_id": None}
            pods[pod_id] = pod
        # The browser can't reliably know its own LAN IP; the source
        # address of this very request is a better answer anyway.
        pod["ip"] = request.remote_addr or pod["ip"]
        pod["last_seen"] = time.time()
        return jsonify(pod)


@app.route("/api/pods")
def api_list_pods():
    with _lock:
        return jsonify({"pods": list(pods.values())})


@app.route("/api/pods/<pod_id>/events")
def api_pod_events(pod_id):
    q: "queue.Queue" = queue.Queue()
    with _lock:
        _subscribers.setdefault(pod_id, []).append(q)

    def stream():
        try:
            yield "retry: 2000\n\n"
            while True:
                try:
                    event, payload = q.get(timeout=15)
                    yield f"event: {event}\ndata: {payload}\n\n"
                except queue.Empty:
                    yield ": keepalive\n\n"
        finally:
            with _lock:
                subs = _subscribers.get(pod_id, [])
                if q in subs:
                    subs.remove(q)

    return Response(stream(), mimetype="text/event-stream")


@app.route("/api/groups", methods=["POST", "OPTIONS"])
def api_create_group():
    if request.method == "OPTIONS":
        return ""
    body = request.get_json(force=True, silent=True) or {}
    inviter_id = body.get("inviter_pod_id")
    invitee_ids = body.get("invitee_pod_ids", [])
    inviter_name = body.get("inviter_name", "") or inviter_id

    with _lock:
        if inviter_id not in pods:
            return jsonify({"error": f"Unknown pod '{inviter_id}'"}), 404
        for pid in invitee_ids:
            if pid not in pods:
                return jsonify({"error": f"Unknown pod '{pid}'"}), 404
            if pods[pid]["status"] != "idle":
                return jsonify({"error": f"Pod '{pid}' is not idle"}), 409

        group_id = uuid.uuid4().hex[:8]
        member_ids = [inviter_id] + invitee_ids
        group = {
            "group_id": group_id,
            "inviter_pod_id": inviter_id,
            "member_pod_ids": member_ids,
            "invite_status": {pid: ("accepted" if pid == inviter_id else "pending") for pid in member_ids},
            "state": "pending",
            # customer_names is set by each pod itself -- the inviter
            # here, invitees via /respond when they accept -- rather
            # than through /config (which only the inviter can call
            # and which does a shallow dict.update, so it can't safely
            # merge into a nested dict other pods also write to).
            "config": {"customer_names": {inviter_id: inviter_name}},
            "acserver_instance": None,
            "created_at": time.time(),
            "ended_reason": None,
        }
        groups[group_id] = group

        pods[inviter_id]["status"] = "in_group"
        pods[inviter_id]["group_id"] = group_id
        for pid in invitee_ids:
            pods[pid]["status"] = "invited"
            pods[pid]["group_id"] = group_id

        _publish_to_group(group, "invited", group)
        return jsonify(group)


@app.route("/api/groups/<group_id>")
def api_get_group(group_id):
    with _lock:
        group = groups.get(group_id)
        if group is None:
            return jsonify({"error": "No such group"}), 404
        return jsonify(group)


@app.route("/api/groups/<group_id>/respond", methods=["POST", "OPTIONS"])
def api_respond(group_id):
    if request.method == "OPTIONS":
        return ""
    body = request.get_json(force=True, silent=True) or {}
    pod_id = body.get("pod_id")
    response = body.get("response")  # "accept" | "decline"
    customer_name = body.get("customer_name", "")

    with _lock:
        group = groups.get(group_id)
        if group is None:
            return jsonify({"error": "No such group"}), 404
        if pod_id not in group["invite_status"]:
            return jsonify({"error": f"Pod '{pod_id}' is not a member of this group"}), 403
        if group["state"] != "pending":
            return jsonify({"error": f"Group is '{group['state']}', can't respond now"}), 409
        if response not in ("accept", "decline"):
            return jsonify({"error": "response must be 'accept' or 'decline'"}), 400

        group["invite_status"][pod_id] = "accepted" if response == "accept" else "declined"
        if response == "accept" and pod_id in pods:
            pods[pod_id]["status"] = "in_group"
            group["config"]["customer_names"][pod_id] = customer_name or pod_id

        _publish_to_group(group, "member_responded", {"group_id": group_id, "pod_id": pod_id, "response": response})

        if response == "decline":
            # Whole shared session ends if anyone declines -- explicit
            # earlier decision, not an oversight.
            _end_group(group, reason=f"declined_by_{pod_id}")
        else:
            all_accepted = all(v == "accepted" for v in group["invite_status"].values())
            if all_accepted:
                _publish_to_group(group, "all_accepted", {"group_id": group_id})

        return jsonify(group)


@app.route("/api/groups/<group_id>/config", methods=["POST", "OPTIONS"])
def api_update_config(group_id):
    if request.method == "OPTIONS":
        return ""
    body = request.get_json(force=True, silent=True) or {}
    pod_id = body.get("pod_id")

    with _lock:
        group = groups.get(group_id)
        if group is None:
            return jsonify({"error": "No such group"}), 404
        if pod_id != group["inviter_pod_id"]:
            return jsonify({"error": "Only the inviter can update session config"}), 403
        if group["state"] != "pending":
            return jsonify({"error": f"Group is '{group['state']}', can't change config now"}), 409

        fields = {k: v for k, v in body.items() if k not in ("pod_id",)}
        group["config"].update(fields)
        _publish_to_group(group, "config_updated", {"group_id": group_id, "config": group["config"]})
        return jsonify(group)


@app.route("/api/groups/<group_id>/start", methods=["POST", "OPTIONS"])
def api_start_session(group_id):
    if request.method == "OPTIONS":
        return ""
    body = request.get_json(force=True, silent=True) or {}
    pod_id = body.get("pod_id")

    with _lock:
        group = groups.get(group_id)
        if group is None:
            return jsonify({"error": "No such group"}), 404
        if pod_id != group["inviter_pod_id"]:
            return jsonify({"error": "Only the inviter can start the session"}), 403
        if group["state"] != "pending":
            return jsonify({"error": f"Group is already '{group['state']}'"}), 409
        if not all(v == "accepted" for v in group["invite_status"].values()):
            return jsonify({"error": "Not everyone has accepted yet"}), 409

        try:
            pool_cfg = _load_pool_config()
        except FileNotFoundError as exc:
            return jsonify({"error": str(exc)}), 500

        instance_id = _free_instance_id(pool_cfg)
        if instance_id is None:
            return jsonify({"error": "All 4 acServer instances are currently in use"}), 409

        instance = next(i for i in pool_cfg["instances"] if i["id"] == instance_id)
        cfg = group["config"]

        server_cfg_text = acserver_manager.build_server_cfg(
            acserver_manager.ServerSessionConfig(
                name=f"Kiosk group {group_id}",
                track=cfg.get("track_id", ""),
                track_layout=cfg.get("track_layout", ""),
                cars=[cfg.get("car_id", "")],
                session_type=cfg.get("session_type", "practice"),
                duration_minutes=int(cfg.get("duration_minutes", 20)),
                laps=50,
                udp_port=instance["port"],
                tcp_port=instance["port"],
                http_port=instance["http_port"],
                max_clients=len(group["member_pod_ids"]),
            )
        )
        drivers = [
            acserver_manager.Driver(
                car=cfg.get("car_id", ""),
                driver_name=cfg["customer_names"].get(pid, pid),
            )
            for pid in group["member_pod_ids"]
        ]
        entry_list_text = acserver_manager.build_entry_list(drivers)
        acserver_manager.write_instance_config(instance["config_dir"], server_cfg_text, entry_list_text)

        try:
            proc = acserver_manager.restart_instance(
                pool_cfg["acserver_exe"], instance["config_dir"], _running_instances.get(instance_id)
            )
            _running_instances[instance_id] = proc
        except FileNotFoundError as exc:
            return jsonify({"error": str(exc)}), 500

        group["acserver_instance"] = instance_id
        group["state"] = "active"

        connection = {
            "server_ip": instance.get("server_ip", ""),
            "server_port": instance["port"],
            "server_http_port": instance["http_port"],
        }
        _publish_to_group(group, "session_started", {"group_id": group_id, "connection": connection, "config": cfg})
        return jsonify(group)


@app.route("/api/groups/<group_id>/end", methods=["POST", "OPTIONS"])
def api_end_session(group_id):
    if request.method == "OPTIONS":
        return ""
    body = request.get_json(force=True, silent=True) or {}
    pod_id = body.get("pod_id")
    reason = body.get("reason", "ended_by_participant")

    with _lock:
        group = groups.get(group_id)
        if group is None:
            return jsonify({"error": "No such group"}), 404
        if pod_id not in group["member_pod_ids"]:
            return jsonify({"error": f"Pod '{pod_id}' is not a member of this group"}), 403
        _end_group(group, reason=reason)
        return jsonify(group)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=6000, threaded=True)
