"""
app.py

Phase 1: the actual customer-facing single-player kiosk picker, as a
small local Flask web app. Meant to run full-screen in a browser on
each pod, replacing phase0_test.py's command-line harness with
something a customer can click (or, in a later phase, drive with the
wheel/pedals) through themselves.

Scope of this pass, deliberately: single-player only. Multiplayer's
invite-first flow is its own later phase. Wheel/pedal navigation is
not wired up yet either — the frontend's keyboard handling (arrow
keys to move focus, Enter to select, Backspace to go back) is
structured so that a wheel/pedal input layer can drive the same
actions later without restructuring the UI.

Known gap, called out rather than silently skipped: the 1-60 minute
session-length slider sets race.ini's DURATION_MINUTES directly for
Practice sessions (a real, verified field). For Race sessions, AC
takes a lap count instead of a duration (race.ini's LAPS field, per
race_ini.py) -- there's no verified way to make a native AC race
session simply "run for N minutes". So for Race, this picker still
shows the same duration slider (matching the original requirement:
customers choose session length regardless of mode), but converts it
to a generous fixed lap count for now and does NOT yet enforce a real
time-based cutoff. Actually stopping a race session at the customer's
chosen time (or when their booked time runs out) needs the external
session-time-monitor component from the architecture brief -- a
separate piece, not built in this pass.

Run it with:
    pip install -r requirements.txt
    python app.py
Then open http://localhost:5000 in a browser (or point the pod's
kiosk browser at it directly).
"""

import os
import sys

from flask import Flask, jsonify, request, send_file, send_from_directory

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "common"))

from direct_launch import write_and_launch  # noqa: E402
from race_ini import RaceConfig, AIOpponent, build_race_ini  # noqa: E402

import content_scan
import packs

APP_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(APP_DIR, "static")
PACKS_JSON_PATH = os.path.join(APP_DIR, "packs.json")

app = Flask(__name__, static_folder=None)

_config_cache = None


def get_config() -> dict:
    """Loaded once and cached -- restart the app if you edit packs.json.
    Fine for a kiosk process that's already restarted between customers/
    sessions; revisit if that stops being true."""
    global _config_cache
    if _config_cache is None:
        _config_cache = packs.load_config(PACKS_JSON_PATH)
    return _config_cache


# ---------------------------------------------------------------- SPA


@app.route("/")
def index():
    return send_from_directory(STATIC_DIR, "index.html")


@app.route("/app.js")
def app_js():
    return send_from_directory(STATIC_DIR, "app.js")


@app.route("/style.css")
def style_css():
    return send_from_directory(STATIC_DIR, "style.css")


# ---------------------------------------------------------------- API


@app.route("/api/packs")
def api_packs():
    try:
        cfg = get_config()
    except packs.PacksConfigError as exc:
        return jsonify({"error": str(exc)}), 500
    return jsonify({"packs": packs.list_packs(cfg)})


@app.route("/api/packs/<pack_id>")
def api_pack_detail(pack_id):
    try:
        cfg = get_config()
        pack = packs.get_pack(cfg, pack_id)
    except packs.PacksConfigError as exc:
        return jsonify({"error": str(exc)}), 404

    ac_dir = cfg["ac_install_dir"]

    cars = []
    for car_id in pack.get("cars", []):
        info = content_scan.car_info(ac_dir, car_id)
        cars.append({"id": info.car_id, "name": info.name, "brand": info.brand})

    tracks = []
    for track_id in pack.get("tracks", []):
        info = content_scan.track_info(ac_dir, track_id)
        tracks.append({
            "id": info.track_id,
            "name": info.name,
            "layouts": [{"id": l.layout_id, "name": l.name} for l in info.layouts],
        })

    return jsonify({"id": pack_id, "label": pack.get("label", pack_id), "cars": cars, "tracks": tracks})


@app.route("/api/content/car/<car_id>/preview")
def api_car_preview(car_id):
    cfg = get_config()
    info = content_scan.car_info(cfg["ac_install_dir"], car_id)
    if not info.preview_path:
        return "", 404
    return send_file(info.preview_path)


@app.route("/api/content/track/<track_id>/preview")
def api_track_preview(track_id):
    layout_id = request.args.get("layout", "")
    cfg = get_config()
    info = content_scan.track_info(cfg["ac_install_dir"], track_id)
    for layout in info.layouts:
        if layout.layout_id == layout_id:
            if not layout.preview_path:
                return "", 404
            return send_file(layout.preview_path)
    return "", 404


@app.route("/api/session/start", methods=["POST"])
def api_session_start():
    cfg = get_config()
    body = request.get_json(force=True, silent=True) or {}

    required = ["customer_name", "car_id", "track_id", "session_type", "duration_minutes"]
    missing = [k for k in required if k not in body]
    if missing:
        return jsonify({"error": f"Missing fields: {', '.join(missing)}"}), 400

    session_type = body["session_type"]
    if session_type not in ("practice", "race"):
        return jsonify({"error": "session_type must be 'practice' or 'race'"}), 400

    ai_opponents = []
    if session_type == "race":
        ai_count = int(body.get("ai_count", 0))
        ai_level = int(body.get("ai_level", 95))
        for _ in range(ai_count):
            ai_opponents.append(AIOpponent(car=body["car_id"], ai_level=ai_level))

    race_cfg = RaceConfig(
        track=body["track_id"],
        track_layout=body.get("track_layout", ""),
        player_car=body["car_id"],
        driver_name=body["customer_name"] or "Guest Driver",
        session_type=session_type,
        duration_minutes=int(body["duration_minutes"]),
        # See module docstring: race sessions can't take a duration
        # natively yet, so we use a generous lap count as a stand-in
        # until the real time-based cutoff monitor exists.
        laps=50,
        ai_opponents=ai_opponents,
    )
    ini_text = build_race_ini(race_cfg)

    # Printed to the terminal running `python app.py` (which is already
    # being watched during testing) so a bad launch can be diagnosed
    # from the exact race.ini AC actually got, the same way phase0_test.py's
    # command-line output was used earlier -- rather than guessing blind.
    print("----- Generated race.ini -----", flush=True)
    print(ini_text, flush=True)
    print("-------------------------------", flush=True)
    print(f"TRACK={race_cfg.track}  CONFIG_TRACK={race_cfg.track_layout!r}  MODEL={race_cfg.player_car}", flush=True)

    try:
        written_path = write_and_launch(ini_text, cfg["acs_exe"])
    except FileNotFoundError as exc:
        return jsonify({"error": str(exc)}), 500

    return jsonify({"status": "launched", "race_ini_path": written_path})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
