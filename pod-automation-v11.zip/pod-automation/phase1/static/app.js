/*
 * app.js -- single-player kiosk picker.
 *
 * Navigation model, deliberately kept simple so a later wheel/pedal
 * input layer can drive it without a rewrite: every screen exposes a
 * `keyHandler(event)` function that understands four abstract actions
 *   - "prev" / "next"  (Left/Right today; wheel rotation later)
 *   - "select"         (Enter today; gas pedal later)
 *   - "back"           (Backspace/Escape today; brake pedal later)
 * Mouse/touch clicking a card selects it directly, in parallel with
 * keyboard nav -- both fully work today, per the current phase scope.
 *
 * Each screen function re-renders from global state `S` and can be
 * safely re-entered (e.g. when the user goes Back to it), refetching
 * from the API as needed rather than assuming cached data is still
 * valid.
 */

const app = document.getElementById("app");

const S = {
  customerName: "",
  packId: null,
  packLabel: "",
  carId: null,
  carName: "",
  trackId: null,
  trackName: "",
  layoutId: "",
  layoutName: "",
  sessionType: null, // "practice" | "race"
  durationMinutes: 20,
  aiCount: 3,
  aiLevel: 90,
};

let history = [];
let currentScreen = null;
let currentKeyHandler = null;

function goto(screenFn) {
  if (currentScreen) history.push(currentScreen);
  currentScreen = screenFn;
  screenFn();
}

function back() {
  const prev = history.pop();
  if (prev) {
    currentScreen = prev;
    prev();
  }
}

document.addEventListener("keydown", (e) => {
  // Don't hijack Backspace while the customer is actually typing in a
  // text field (name entry) -- only treat it as "go back" elsewhere.
  const activeTag = document.activeElement && document.activeElement.tagName;
  const typingInField = activeTag === "INPUT" || activeTag === "TEXTAREA";

  if (e.key === "Escape" || (e.key === "Backspace" && !typingInField)) {
    e.preventDefault();
    back();
    return;
  }
  if (currentKeyHandler) currentKeyHandler(e);
});

async function api(path, opts) {
  const res = await fetch(path, opts);
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request to ${path} failed (${res.status})`);
  }
  return res.json();
}

// ---------------------------------------------------------- helpers

function el(html) {
  const t = document.createElement("template");
  t.innerHTML = html.trim();
  return t.content.firstChild;
}

function renderScreen(innerHtml) {
  app.innerHTML = "";
  const screen = el(`<div class="screen">${innerHtml}</div>`);
  app.appendChild(screen);
  return screen;
}

/* A single-row, keyboard + click navigable list of items. `items` is
 * an array of {id, render(): htmlString}. Calls onSelect(item) when
 * chosen. Returns nothing -- wires currentKeyHandler itself.
 *
 * Builds each card's DOM element exactly once. Moving focus (hover or
 * arrow keys) only toggles the "focused" class -- it does NOT rebuild
 * the DOM. Rebuilding on every mouseenter (the original approach) let
 * a hover-triggered rebuild swap out the very element the browser was
 * about to fire a click on, which made clicks silently do nothing
 * with no console error -- exactly the symptom hit on real hardware. */
function mountCarousel(container, items, onSelect, startIndex = 0) {
  let focusIndex = Math.min(startIndex, items.length - 1);
  const cardEls = [];

  function updateFocus() {
    cardEls.forEach((cardEl, i) => cardEl.classList.toggle("focused", i === focusIndex));
    const focused = cardEls[focusIndex];
    if (focused) focused.scrollIntoView({ block: "nearest", inline: "nearest" });
  }

  container.innerHTML = "";
  items.forEach((item, i) => {
    const cardEl = el(item.render());
    cardEl.addEventListener("click", () => onSelect(item));
    cardEl.addEventListener("mouseenter", () => {
      focusIndex = i;
      updateFocus();
    });
    container.appendChild(cardEl);
    cardEls.push(cardEl);
  });
  updateFocus();

  currentKeyHandler = (e) => {
    if (e.key === "ArrowRight") {
      e.preventDefault();
      focusIndex = Math.min(focusIndex + 1, items.length - 1);
      updateFocus();
    } else if (e.key === "ArrowLeft") {
      e.preventDefault();
      focusIndex = Math.max(focusIndex - 1, 0);
      updateFocus();
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (items[focusIndex]) onSelect(items[focusIndex]);
    }
  };
}

/* A simple N-option menu (big buttons in a row). Same fix as
 * mountCarousel above: build once, toggle "focused" on hover/arrow
 * keys instead of rebuilding the DOM out from under a click. */
function mountMenu(container, options, onSelect, startIndex = 0) {
  let focusIndex = startIndex;
  const btnEls = [];

  function updateFocus() {
    btnEls.forEach((btn, i) => btn.classList.toggle("focused", i === focusIndex));
  }

  container.innerHTML = "";
  options.forEach((opt, i) => {
    const btn = el(`<div class="menu-btn">${opt.label}</div>`);
    btn.addEventListener("click", () => onSelect(opt));
    btn.addEventListener("mouseenter", () => {
      focusIndex = i;
      updateFocus();
    });
    container.appendChild(btn);
    btnEls.push(btn);
  });
  updateFocus();

  currentKeyHandler = (e) => {
    if (e.key === "ArrowRight") {
      e.preventDefault();
      focusIndex = Math.min(focusIndex + 1, options.length - 1);
      updateFocus();
    } else if (e.key === "ArrowLeft") {
      e.preventDefault();
      focusIndex = Math.max(focusIndex - 1, 0);
      updateFocus();
    } else if (e.key === "Enter") {
      e.preventDefault();
      onSelect(options[focusIndex]);
    }
  };
}

/* A single slider with keyboard Left/Right adjust + Enter to confirm. */
function mountSlider(valueEl, sliderEl, { min, max, step, value, onChange, onConfirm }) {
  sliderEl.min = min;
  sliderEl.max = max;
  sliderEl.step = step;
  sliderEl.value = value;
  valueEl.textContent = value;

  sliderEl.addEventListener("input", () => {
    onChange(Number(sliderEl.value));
    valueEl.textContent = sliderEl.value;
  });

  currentKeyHandler = (e) => {
    if (e.key === "ArrowRight") {
      e.preventDefault();
      sliderEl.value = Math.min(Number(sliderEl.value) + step, max);
      sliderEl.dispatchEvent(new Event("input"));
    } else if (e.key === "ArrowLeft") {
      e.preventDefault();
      sliderEl.value = Math.max(Number(sliderEl.value) - step, min);
      sliderEl.dispatchEvent(new Event("input"));
    } else if (e.key === "Enter") {
      e.preventDefault();
      onConfirm();
    }
  };
}

// ----------------------------------------------------------- screens

function screenWelcome() {
  const screen = renderScreen(`
    <div class="welcome">
      <div class="eyebrow">The Swing Spot</div>
      <div class="title">Ready to Race?</div>
      <div class="tap-cta">Tap anywhere or press Enter to start</div>
    </div>
  `);
  const start = () => goto(screenName);
  screen.addEventListener("click", start);
  currentKeyHandler = (e) => {
    if (e.key === "Enter") start();
  };
}

function screenName() {
  const screen = renderScreen(`
    <div class="eyebrow">Step 1 of 6</div>
    <div class="title">What's your name?</div>
    <input class="name-input" type="text" placeholder="Enter your name" maxlength="24" />
    <div class="hint">Press Enter to continue, or leave blank for "Guest"</div>
  `);
  const input = screen.querySelector("input");
  input.value = S.customerName;
  input.focus();

  const submit = () => {
    S.customerName = input.value.trim() || "Guest";
    goto(screenPack);
  };

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") submit();
  });
  currentKeyHandler = null; // input field owns its own key events
}

async function screenPack() {
  const screen = renderScreen(`
    <div class="eyebrow">Step 2 of 6</div>
    <div class="title">Choose a content pack</div>
    <div class="carousel" id="carousel"></div>
    <div class="hint">Use ← / → and Enter, or click a pack</div>
  `);
  let data;
  try {
    data = await api("/api/packs");
  } catch (err) {
    renderError(screen, err.message, screenPack);
    return;
  }

  const container = screen.querySelector("#carousel");
  const items = data.packs.map((p) => ({
    id: p.id,
    render: () => `
      <div class="card">
        <div class="thumb">${escapeHtml(p.label)}</div>
        <div class="label"><div class="name">${escapeHtml(p.label)}</div></div>
      </div>`,
  }));

  mountCarousel(container, items, (item) => {
    S.packId = item.id;
    S.packLabel = data.packs.find((p) => p.id === item.id).label;
    goto(screenCar);
  });
}

async function screenCar() {
  const screen = renderScreen(`
    <div class="eyebrow">Step 3 of 6 &middot; ${escapeHtml(S.packLabel)}</div>
    <div class="title">Choose your car</div>
    <div class="carousel" id="carousel"></div>
    <div class="hint">Use ← / → and Enter, or click a car</div>
  `);
  let data;
  try {
    data = await api(`/api/packs/${encodeURIComponent(S.packId)}`);
  } catch (err) {
    renderError(screen, err.message, screenCar);
    return;
  }

  const container = screen.querySelector("#carousel");
  const items = data.cars.map((c) => ({
    id: c.id,
    render: () => `
      <div class="card">
        <div class="thumb"><img src="/api/content/car/${encodeURIComponent(c.id)}/preview" onerror="this.parentElement.textContent='No preview'" /></div>
        <div class="label">
          <div class="name">${escapeHtml(c.name)}</div>
          <div class="sub">${escapeHtml(c.brand || "")}</div>
        </div>
      </div>`,
  }));

  mountCarousel(container, items, (item) => {
    const car = data.cars.find((c) => c.id === item.id);
    S.carId = car.id;
    S.carName = car.name;
    goto(screenTrack);
  });
}

async function screenTrack() {
  const screen = renderScreen(`
    <div class="eyebrow">Step 4 of 6 &middot; ${escapeHtml(S.packLabel)}</div>
    <div class="title">Choose your track</div>
    <div class="carousel" id="carousel"></div>
    <div class="hint">Use ← / → and Enter, or click a track</div>
  `);
  let data;
  try {
    data = await api(`/api/packs/${encodeURIComponent(S.packId)}`);
  } catch (err) {
    renderError(screen, err.message, screenTrack);
    return;
  }

  const container = screen.querySelector("#carousel");
  const items = data.tracks.map((t) => ({
    id: t.id,
    render: () => `
      <div class="card">
        <div class="thumb"><img src="/api/content/track/${encodeURIComponent(t.id)}/preview" onerror="this.parentElement.textContent='No preview'" /></div>
        <div class="label"><div class="name">${escapeHtml(t.name)}</div></div>
      </div>`,
  }));

  mountCarousel(container, items, (item) => {
    const track = data.tracks.find((t) => t.id === item.id);
    S.trackId = track.id;
    S.trackName = track.name;
    if (track.layouts.length > 1) {
      goto(() => screenLayout(track));
    } else {
      S.layoutId = track.layouts[0] ? track.layouts[0].id : "";
      S.layoutName = track.layouts[0] ? track.layouts[0].name : "";
      goto(screenSessionType);
    }
  });
}

function screenLayout(track) {
  const screen = renderScreen(`
    <div class="eyebrow">Step 4 of 6 &middot; ${escapeHtml(S.trackName)}</div>
    <div class="title">Choose a layout</div>
    <div class="carousel" id="carousel"></div>
    <div class="hint">Use ← / → and Enter, or click a layout</div>
  `);
  const container = screen.querySelector("#carousel");
  const items = track.layouts.map((l) => ({
    id: l.layout_id,
    render: () => `
      <div class="card">
        <div class="thumb"><img src="/api/content/track/${encodeURIComponent(track.id)}/preview?layout=${encodeURIComponent(l.layout_id)}" onerror="this.parentElement.textContent='No preview'" /></div>
        <div class="label"><div class="name">${escapeHtml(l.name)}</div></div>
      </div>`,
  }));

  mountCarousel(container, items, (item) => {
    const layout = track.layouts.find((l) => l.layout_id === item.id);
    S.layoutId = layout.layout_id;
    S.layoutName = layout.name;
    goto(screenSessionType);
  });
}

function screenSessionType() {
  const screen = renderScreen(`
    <div class="eyebrow">Step 5 of 6</div>
    <div class="title">Practice or Race?</div>
    <div class="menu" id="menu"></div>
    <div class="hint">Use ← / → and Enter, or click an option</div>
  `);
  const container = screen.querySelector("#menu");
  mountMenu(
    container,
    [
      { id: "practice", label: "Practice" },
      { id: "race", label: "Race (with AI opponents)" },
    ],
    (opt) => {
      S.sessionType = opt.id;
      goto(screenDuration);
    }
  );
}

function screenDuration() {
  const screen = renderScreen(`
    <div class="eyebrow">Step 6 of 6</div>
    <div class="title">How long do you want to drive?</div>
    <div class="slider-block">
      <div class="slider-value" id="value"></div>
      <div class="slider-row">
        <input type="range" id="slider" />
      </div>
      <div class="slider-hint">1 to 60 minutes &middot; press Enter to continue</div>
    </div>
  `);
  const valueEl = screen.querySelector("#value");
  const sliderEl = screen.querySelector("#slider");

  const paintValue = (v) => (valueEl.textContent = `${v} min`);
  paintValue(S.durationMinutes);

  mountSlider(valueEl, sliderEl, {
    min: 1,
    max: 60,
    step: 1,
    value: S.durationMinutes,
    onChange: (v) => {
      S.durationMinutes = v;
      paintValue(v);
    },
    onConfirm: () => {
      if (S.sessionType === "race") {
        goto(screenAiSettings);
      } else {
        goto(screenConfirm);
      }
    },
  });
}

function screenAiSettings() {
  const screen = renderScreen(`
    <div class="eyebrow">AI Opponents</div>
    <div class="title">Number of opponents</div>
    <div class="slider-block">
      <div class="slider-value" id="countValue"></div>
      <div class="slider-row"><input type="range" id="countSlider" /></div>
      <div class="slider-hint">0 to 8 &middot; press Enter to continue to skill level</div>
    </div>
  `);
  const countValueEl = screen.querySelector("#countValue");
  const countSliderEl = screen.querySelector("#countSlider");
  const paintCount = (v) => (countValueEl.textContent = `${v} car${v === 1 ? "" : "s"}`);
  paintCount(S.aiCount);

  mountSlider(countValueEl, countSliderEl, {
    min: 0,
    max: 8,
    step: 1,
    value: S.aiCount,
    onChange: (v) => {
      S.aiCount = v;
      paintCount(v);
    },
    onConfirm: () => {
      if (S.aiCount === 0) {
        goto(screenConfirm);
      } else {
        goto(screenAiSkill);
      }
    },
  });
}

function screenAiSkill() {
  const screen = renderScreen(`
    <div class="eyebrow">AI Opponents</div>
    <div class="title">Opponent skill level</div>
    <div class="slider-block">
      <div class="slider-value" id="skillValue"></div>
      <div class="slider-row"><input type="range" id="skillSlider" /></div>
      <div class="slider-hint">80 (relaxed) to 100 (very fast) &middot; press Enter to continue</div>
    </div>
  `);
  const skillValueEl = screen.querySelector("#skillValue");
  const skillSliderEl = screen.querySelector("#skillSlider");
  const paintSkill = (v) => (skillValueEl.textContent = v);
  paintSkill(S.aiLevel);

  mountSlider(skillValueEl, skillSliderEl, {
    min: 80,
    max: 100,
    step: 1,
    value: S.aiLevel,
    onChange: (v) => {
      S.aiLevel = v;
      paintSkill(v);
    },
    onConfirm: () => goto(screenConfirm),
  });
}

function screenConfirm() {
  const rows = [
    ["Driver", S.customerName],
    ["Pack", S.packLabel],
    ["Car", S.carName],
    ["Track", S.layoutName || S.trackName],
    ["Session", S.sessionType === "race" ? "Race" : "Practice"],
    ["Length", `${S.durationMinutes} min`],
  ];
  if (S.sessionType === "race") {
    rows.push(["AI opponents", `${S.aiCount} @ skill ${S.aiLevel}`]);
  }

  const screen = renderScreen(`
    <div class="eyebrow">Ready to go, ${escapeHtml(S.customerName)}?</div>
    <div class="title">Confirm your session</div>
    <div class="summary">
      ${rows.map(([k, v]) => `<div class="summary-row"><span class="k">${escapeHtml(k)}</span><span class="v">${escapeHtml(String(v))}</span></div>`).join("")}
    </div>
    <div class="primary-btn focused" id="startBtn">Start Session</div>
    <div class="hint">Press Enter to start, or Backspace to change something</div>
  `);

  const startBtn = screen.querySelector("#startBtn");
  const start = () => goto(screenLaunching);
  startBtn.addEventListener("click", start);
  currentKeyHandler = (e) => {
    if (e.key === "Enter") start();
  };
}

async function screenLaunching() {
  renderScreen(`
    <div class="status-screen">
      <div class="spinner"></div>
      <div class="title" style="font-size:28px;">Starting your session&hellip;</div>
    </div>
  `);
  currentKeyHandler = null;

  try {
    const result = await api("/api/session/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        customer_name: S.customerName,
        car_id: S.carId,
        track_id: S.trackId,
        track_layout: S.layoutId,
        session_type: S.sessionType,
        duration_minutes: S.durationMinutes,
        ai_count: S.aiCount,
        ai_level: S.aiLevel,
      }),
    });
    renderScreen(`
      <div class="status-screen">
        <div class="success-msg">Session launched!</div>
        <div class="hint">${escapeHtml(result.race_ini_path || "")}</div>
      </div>
    `);
  } catch (err) {
    const screen = renderScreen(`
      <div class="status-screen">
        <div class="title" style="font-size:28px;color:var(--error);">Couldn't start the session</div>
        <div class="error-msg">${escapeHtml(err.message)}</div>
        <div class="primary-btn focused" id="retryBtn" style="margin-top:32px;">Back to Confirm</div>
      </div>
    `);
    const retryBtn = screen.querySelector("#retryBtn");
    const retry = () => goto(screenConfirm);
    retryBtn.addEventListener("click", retry);
    currentKeyHandler = (e) => {
      if (e.key === "Enter") retry();
    };
  }
}

function renderError(screen, message, retryScreenFn) {
  screen.insertAdjacentHTML(
    "beforeend",
    `<div class="error-msg">${escapeHtml(message)}</div>
     <div class="primary-btn focused" id="retryBtn" style="margin-top:24px;">Retry</div>`
  );
  const retryBtn = screen.querySelector("#retryBtn");
  // Re-run the same screen directly (it's already `currentScreen` --
  // goto() was called to get here) rather than going through goto(),
  // which would push a duplicate entry onto the back-navigation history.
  const retry = () => retryScreenFn();
  retryBtn.addEventListener("click", retry);
  currentKeyHandler = (e) => {
    if (e.key === "Enter") retry();
  };
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str == null ? "" : str;
  return div.innerHTML;
}

// ------------------------------------------------------------- boot

goto(screenWelcome);
