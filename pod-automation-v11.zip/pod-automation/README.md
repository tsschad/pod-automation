# Pod automation — The Swing Spot

Custom software to run 4 Assetto Corsa sim-racing pods against a central
control PC: a self-serve kiosk UI on each pod (single player vs.
multiplayer, curated content packs, wheel/pedal navigation, time-based
sessions tied to bookings) and an admin GUI on the control PC (content
packs, live pod/server status, customer check-in, driver stats).

See the full feasibility and architecture brief (shared separately as a
Word doc) for the complete design. This repo is the actual code, built up
phase by phase against that plan.

## Layout

- `common/` — the shared launch mechanics used by every phase: builds
  `race.ini` (`race_ini.py`), writes it to the right path and launches
  `acs.exe` directly (`direct_launch.py`), the now-deprecated Content
  Manager URI approach (`cm_launcher.py`, kept for reference), and the
  Drive-icon auto-click workaround for the post-launch "Session
  information" screen (`drive_click.py` / `ahk_click.py` +
  `drive_click.ahk`).
- `phase0/` — the command-line proof-of-concept (`phase0_test.py`) that
  exercises everything in `common/` from the terminal, for testing
  directly on a pod without any UI. See `phase0/README.md`.
- `phase1/` — the real customer-facing single-player kiosk picker: a
  small local Flask app + full-screen web UI (name entry, content pack,
  car, track, Practice/Race, session length, AI opponents, confirm,
  launch). Reads real installed AC content for car/track names and
  preview images. See `phase1/README.md`.

Later phases (multiplayer's invite-first flow, the control PC service,
the admin GUI, driver stats/results) will land in their own folders here
as they're built.

## Status

Phase 0 complete enough to build on: `race_ini.py` is validated against a
real single-player Practice race.ini from a pod, and the direct
write-race.ini-then-launch-acs.exe mechanism is proven on real hardware
(right car/track loads). Open items: a Race-type session capture (to
confirm LAPS vs. DURATION_MINUTES), a capture with AI opponents in the
grid, the result-file format/location, whether `race/online/join` works
for multiplayer, and getting past the post-launch "Session information"
screen without a manual click (see `phase0/README.md` — currently
tracked as a to-do, not blocking further work).

Phase 1 (single-player kiosk picker) built and logic-tested; not yet
tested end-to-end on a real pod with real content packs.
