# Control PC — multiplayer coordinator

Runs on the control PC (the same machine that will eventually run the
4 acServer instances). Every pod's browser talks to this service
directly for anything multiplayer-related — who's online, sending and
responding to invites, live config updates as the host picks a
pack/car/track, and starting/ending a shared session. See
`coordinator.py`'s module docstring for the full state model.

## Status

Built and logic-tested (state machine, authorization checks, decline/
timeout/end behavior — see below), but **not run on real hardware
yet**, and the multiplayer *join* mechanism itself
(`race.ini`'s `REMOTE` section + direct launch, in `phase1/app.py`'s
`/api/mp/join`) has never been tested on a real pod either — same
caveat `race_ini.py` and `phase0_test.py`'s `mp-ini` command have
carried since before single-player was proven out. Test this early,
the same way Phase 0 shook out the issues with the single-player path.

`acserver_manager.py`'s `server_cfg.ini`/`entry_list.ini` format is
reconstructed from public AC dedicated-server documentation, **not**
verified against a real file — the same situation `race_ini.py` was in
before Chad captured a real reference file and it got corrected. If
you already have working acServer instances running, capturing one of
their real `server_cfg.ini`/`entry_list.ini` files and comparing would
settle this fast.

## Setup

1. Copy `acserver_pool.example.json` to `acserver_pool.json` and fill
   in:
   - `acserver_exe` — path to `acServer.exe`
   - 4 `instances`, each with its own `config_dir` (a folder this
     service writes `server_cfg.ini`/`entry_list.ini` into), `port`,
     and `http_port`. See the module docstring in `acserver_manager.py`
     for the open question about whether one shared `acServer.exe`
     with `-c`/`-e` flags actually works for running 4 independent
     instances, or whether each needs its own copy of the executable.

2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Run it:
   ```
   python coordinator.py
   ```
   Listens on `0.0.0.0:6000`.

4. Each pod needs `phase1/mp_config.json` pointing at this machine —
   see `phase1/README.md`.

## Scope decision, flagged rather than assumed

The **host/inviter picks the pack, car, track, session type, and
duration for the whole group** — everyone races the same car, not each
person picking their own. This keeps `entry_list.ini` assignment
simple and the invite flow easy to follow for a first pass. Extending
to per-player car choice is a reasonable next step once the core join
mechanism is actually proven working on hardware — that's the bigger
unknown here, not this decision.

## Known gap, not built here

Nothing currently calls `_end_group(..., reason="time_expired")`
automatically. That needs the booking-system clock hook described in
the architecture brief (Section 4) — still not built, same gap already
flagged for `phase1`'s single-player Race sessions. The `/api/groups/
<id>/end` endpoint is ready for a future booking-time-monitor
component to call; nothing wires it up yet.

## What was actually tested (without Flask installed)

Flask isn't installable in the sandbox this was built in, so testing
worked the same way it did for `phase1`: stub out `flask`'s `Flask`/
`jsonify`/`request`/`Response` and call the route functions directly.
Verified:

- Full happy path: register 2+ pods → create a group → inviter updates
  config → invitees accept (with their name merged in via `/respond`,
  since only the inviter can call `/config`) → `all_accepted` → start
  (reaches `acserver_manager`, fails cleanly on a fake `acServer.exe`
  path, as expected in a sandbox with no real install).
- A decline ends the whole group and frees every member pod back to
  `idle` — matches the explicit multiplayer decision from earlier in
  the project (not a "only that pod drops out" behavior).
- Authorization: only the inviter can update config or start the
  session; a non-member can't respond to a group they're not in.
- `end_session` frees pods and releases the acServer instance
  regardless of what state the group was in.

Not tested (can't be, without Flask/a browser/real hardware): the
actual HTTP/SSE wiring, CORS behavior in a real browser, or anything
involving `acServer.exe`/`acs.exe` actually running.
